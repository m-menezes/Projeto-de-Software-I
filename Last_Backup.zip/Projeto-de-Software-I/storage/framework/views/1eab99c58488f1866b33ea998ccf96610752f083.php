<?php $__env->startSection('conteudo'); ?>
<?php if(!Auth::check() || Auth::user()->roles != 2 ): ?>
<div class="bg-topo w-100">
	<?php echo $__env->make('_includes.index-topo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<?php echo $__env->make('_includes.sobre', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php else: ?>
<?php if(count($registros) > 0): ?>
<?php $titulo = "Últimos produtos disponíveis"; ?>
<?php echo $__env->make('_includes.titulo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
	<?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<?php $cor = ($registro->status == 'Reservado') ? 'danger' : 'info'; ?>
	<div class="card my-3 w-100" id="card-<?php echo e($registro->id); ?>" style="border-color: <?php echo ($registro->datareserva == NULL) ? '#17a2b8' : 'red'; ?>;">
		<div class="card-body">
			<?php if($registro->idorganizacao != NULL): ?>
			<div class="<?php echo e($cor); ?>-ribbon">Reservado</div>
			<?php else: ?>
			<div class="blue-ribbon">Disponivel</div>
			<?php endif; ?>
			<div class="row">
				<div class="col-md-7">
					<div class="row">
						<div class="col-md-7 text-sm-center text-md-left px-0">
							<h5 class="d-inline weight-300 card-title"><?php echo e($registro->produto); ?></h5>
						</div>
						<div class="col-md-5 text-sm-center text-md-right pt-2">
							<span tabindex="0" class="m-1 text-<?php echo e($cor); ?>" role="button" data-toggle="popover" data-placement="top" data-trigger="hover" data-content="Tipo: <?php echo e($registro->tipo); ?>">
								<i class="fas fa-recycle"></i>
							</span>
							<span tabindex="0" class="m-1 text-<?php echo e($cor); ?>" role="button" data-toggle="popover" data-placement="top" data-trigger="hover" data-content="Data de Registro: <?php echo e($registro->created_at->format('H:i - d/m/Y')); ?>">
								<i class="far fa-calendar-alt"></i>
							</span>
							<span tabindex="0" class="m-1 text-<?php echo e($cor); ?>" id="datareserva<?php echo e($registro->id); ?>" role="button" data-toggle="popover" data-placement="top" data-trigger="hover" data-content="Data de Reserva: <?php echo e(isset($registro->datareserva) ? $registro->datareserva : ''); ?>" <?php if($registro->datareserva == NULL) { echo 'style="display:none"';} ?>>
								<i class="far fa-clock"></i>
							</span>
							<span tabindex="0" class="m-1 text-<?php echo e($cor); ?>" id="idorganizacao<?php echo e($registro->org_name); ?>" role="button" data-toggle="popover" data-placement="top" data-trigger="hover" data-content="Reservado por: <?php echo e($registro->org_name); ?>" <?php if($registro->org_name == NULL) { echo 'style="display:none"';} ?>>
								<i class="fas fa-warehouse"></i>
							</span>
							<span tabindex="0" class="m-1 text-<?php echo e($cor); ?>" id="idorganizacao<?php echo e($registro->org_telefone); ?>" role="button" data-toggle="popover" data-placement="top" data-trigger="hover" data-content="Telefone da empresa: <?php echo e($registro->org_telefone); ?>" <?php if($registro->org_telefone == NULL) { echo 'style="display:none"';} ?>>
								<i class="fas fa-phone"></i>
							</span>
						</div>
					</div>
					<div class="row">
						<p style="width: 100%;"><?php echo e(str_limit($registro->descricao, 350, $end = ' [...]')); ?></p>
					</div>
				</div>
				<div class="col-md-5">
					<p>
						<strong>Endereço: </strong><?php echo e($registro->endereco); ?><br>
						<strong>Nº: </strong><?php echo e($registro->numero); ?><br>
						<strong>Bairro: </strong><?php echo e($registro->bairro); ?><br>
						<strong>Complemento: </strong><?php echo e($registro->complemento); ?><br>
						<strong>CEP: </strong><?php echo e($registro->cep); ?><br>
					</p>
					<div class="row">
						<?php if(Auth::user()->roles != 2 && (Auth::user()->roles == 0 || $registro->idpessoa == Auth::user()->idroles) ): ?>
						<a class="btn btn-outline-danger mr-2 btnExcluir" data-id="<?php echo e($registro->id); ?>">Deletar</a>
						<a class="btn btn-outline-secondary" href="<?php echo e(route('editar_produto', $registro->id)); ?>">Editar</a>
						<?php endif; ?>
						<?php if(Auth::user()->roles == 2): ?>
						<a class="btn btn-outline-<?php echo e($cor); ?>" id="status<?php echo e($registro->id); ?>" href="<?php echo e(route('status_produto', $registro->id)); ?>"><?php echo ($registro->status == 'Reservado') ? 'Cancelar Reserva' : 'Reservar' ?></a>
						<?php endif; ?>
					</div>

				</div>
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>
<?php endif; ?>
<div class="jumbotron w-100">
	<div class="container">
		<h1 class="block-title weight-300">Notícias</h1>
	</div>
</div>
<div class="container p-0 my-5">
	<div class="row">
		<div class="card-columns">
			<?php $__currentLoopData = $noticias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noticia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="card m-0">
				<?php if($noticia->imagem_path): ?>
				<img class="card-img-top" src="<?php echo e($noticia->imagem_path); ?>" alt="<?php echo e($noticia->titulo); ?>">
				<?php endif; ?>
				<div class="card-body">
					<h5 class="card-title"><a class="d-inline-block mb-2 text-success weight-300" href="<?php echo e(route('noticias')); ?>"><?php echo e($noticia->titulo); ?></a></h5>
					<p class="card-text"><?php echo e(str_limit($noticia->descricao, 200, $end = ' [...]')); ?></p>
					<p class="card-text"><small class="text-muted"><?php echo e($noticia->created_at->format('H:i - d/m/Y')); ?></small></p>
					<a class="btn btn-sm btn-outline-secondary" href="<?php echo e(route('noticias')); ?>">Continuar lendo</a>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
<?php echo $__env->make('_includes.documentacao', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<script type="text/javascript">
	$('.popover-dismiss').popover({
		trigger: 'focus'
	})

	$('.btnExcluir').click(function(){
		var id = $(this).attr('data-id');
		var par_url = "<?php echo url('/produto/deletar').'/'; ?>" + id;
		$('#modalExcluir').modal('show');
		$('#btnConfirmar').attr('href', par_url);
	});
</script>
<style>
.blue-ribbon {
	background: #17a2b8;
	color: #FFF;
	padding: 7px 20px;
	position: absolute;
	bottom: 5px;
	right: -1px;
}
.blue-ribbon:before {
	position: absolute;
	right: 0;
	top: 0;
	bottom: 0;
	content: "";
	left: -12px;
	border-top: 19px solid transparent;
	border-right: 12px solid #17a2b8;
	border-bottom: 19px solid transparent;
	width: 0;
}
.danger-ribbon {
	background: #dc3545;
	color: #FFF;
	padding: 7px 20px;
	position: absolute;
	bottom: 5px;
	right: -1px;
}
.danger-ribbon:before {
	position: absolute;
	right: 0;
	top: 0;
	bottom: 0;
	content: "";
	left: -12px;
	border-top: 19px solid transparent;
	border-right: 12px solid #dc3545;
	border-bottom: 19px solid transparent;
	width: 0;
}
</style>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>