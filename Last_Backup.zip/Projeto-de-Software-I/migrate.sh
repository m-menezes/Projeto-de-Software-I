#!/bin/bash
php artisan migrate:refresh --seed;php artisan config:cache;php artisan config:clear;php artisan view:clear;php artisan cache:clear;php artisan route:clear;php artisan optimize;