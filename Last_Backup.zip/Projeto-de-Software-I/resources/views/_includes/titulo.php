<div class="jumbotron w-100">
	<div class="container">
		<h1 class="block-title weight-300"><?php echo $titulo; ?></h1>
	</div>
</div>